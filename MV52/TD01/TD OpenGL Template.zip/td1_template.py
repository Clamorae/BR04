# -*- coding: utf-8 -*-
"""
Created on Mon Jan 27 10:24:40 2020

@author: LAURI
"""


from opengl_fcts import *


class RainbowCube(Object3D):
    def __init__(self):
        super().__init__()

        vertices = [
                -0.5, -0.5, 0.5, 1.0, 0.0, 0.0,
                0.5, -0.5, 0.5, 0.0, 1.0, 0.0,
                0.5, 0.5, 0.5, 0.0, 0.0, 1.0,
                -0.5, 0.5, 0.5, 1.0, 1.0, 1.0,
     
                -0.5, -0.5, -0.5, 1.0, 0.0, 0.0,
                0.5, -0.5, -0.5, 0.0, 1.0, 0.0,
                0.5, 0.5, -0.5, 0.0, 0.0, 1.0,
                -0.5, 0.5, -0.5, 1.0, 1.0, 1.0
                ]

        indices = [0,1,2,
                    2,3,0,
                    4,5,6,
                    6,7,4,
                    4,5,1,
                    1,0,4,
                    6,7,3,
                    3,2,6,
                    5,6,2,
                    2,1,5,
                    7,4,0,
                    0,3,7]

        primitives = [
                (GL_TRIANGLES,indices)
                ]

        self.Shader=ColorPositionShader(vertices,primitives)


    def updateTRSMatrices(self):
        time=glfw.get_time()
        rot_x = pyrr.Matrix44.from_x_rotation(0.5 * time)
        rot_y = pyrr.Matrix44.from_y_rotation(0.8 * time)

        self.R=np.matmul(rot_x,rot_y)


def main():
    window=Window(1024,768,"TD - Template Exercice 1")

    if not window.Window:
        return

    window.initViewMatrix(eye=[0,0,5])

    rc=RainbowCube()
    rc.translate((0.0,0.0,0.0))

    objects=[rc]

    window.render( objects )


if __name__ == "__main__":
    main()
